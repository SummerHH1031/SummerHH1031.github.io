clc;clear all;close all;
%% input 'dct' for dct transform, 'fft' for fft transform
TS_example('dct')