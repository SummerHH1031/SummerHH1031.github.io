#ifndef GUARD_head_h
#define GUARD_head_h
#include <stdio.h>
#include <stdlib.h>
#include "fft.h"
#include <cublas_v2.h>
#include <cusolverDn.h>
#include <cuda_runtime.h>
#include <assert.h>
#include <cufft.h>
#include <iostream>	
#include <string>
#include <sys/time.h>
#include <stdio.h>
#include "common.h"
#define random(x) (float(rand()%x))/x
using namespace std;
#endif
