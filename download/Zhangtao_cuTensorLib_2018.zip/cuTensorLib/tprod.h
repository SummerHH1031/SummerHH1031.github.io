#ifndef GUARD_tprod_h
#define GUARD_tprod_h
#include "fft.h"
#include "head.h"

void tprod(float* t1,float* t2,float* T,int row, int col, int rank, int tupe);

#endif