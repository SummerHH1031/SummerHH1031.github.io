#ifndef GUARD_norm_h
#define GUARD_norm_h
#include <math.h>
#include "head.h"
float norm(float *a,float *b,int n);

#endif